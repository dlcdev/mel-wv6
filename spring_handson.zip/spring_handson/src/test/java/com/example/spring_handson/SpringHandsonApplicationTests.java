package com.example.spring_handson;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringHandsonApplicationTests {

	@Test
	void contextLoads() {
	}

}
